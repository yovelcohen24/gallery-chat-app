<template>
    <div class="picture-page">
      <div class="picture-details">
        <img :src="picture.src" alt="Picture" class="picture-image" />
        <h1>{{ picture.name }}</h1>
        <p>By {{ picture.artist }}</p>
      </div>
      <div class="chat-box">
        <div class="messages">
          <div
            class="message"
            v-for="(message, index) in messages"
            :key="index"
          >
            <strong>{{ message.user }}:</strong> {{ message.text }}
          </div>
        </div>
        <div class="chat-input">
          <input
            type="text"
            v-model="newMessage"
            placeholder="Type your message here..."
          />
          <button @click="sendMessage">Send</button>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        picture: {},
        messages: [],
        newMessage: "",
        ws: null, // WebSocket instance
      };
    },
    created() {
  const id = this.$route.params.id;

  fetch("http://localhost:8000/data.php")
    .then((response) => response.json())
    .then((data) => {
      this.picture = data.find((pic) => pic.id === Number(id));
    })
    .catch((error) => console.error("Error fetching data:", error));

  try {
    this.ws = new WebSocket("ws://localhost:8081");

    this.ws.onopen = () => {
      console.log("WebSocket connection established.");
    };

    this.ws.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data);
        this.messages.push(message);
      } catch (error) {
        console.error("Error parsing WebSocket message:", error);
      }
    };

    this.ws.onerror = (error) => {
      console.error("WebSocket error:", error);
    };

    this.ws.onclose = () => {
      console.log("WebSocket connection closed.");
    };
  } catch (error) {
    console.error("Failed to initialize WebSocket:", error);
  }
},


    methods: {
      sendMessage() {
    if (this.newMessage.trim() !== "") {
      const message = {
        user: "Me",
        text: this.newMessage.trim(),
      };
      this.ws.send(JSON.stringify(message)); 
      this.newMessage = ""; 
    }
      },
    },
    beforeUnmount() {
      if (this.ws) {
        this.ws.close();
      }
    },
  };
  </script>
  
  <style>
  .picture-page {
    display: flex;
    flex-direction: row;
    gap: 20px;
    padding: 20px;
  }
  .picture-details {
    flex: 2;
  }
  .picture-image {
    max-width: 100%;
    border-radius: 8px;
  }
  .chat-box {
    flex: 1;
    display: flex;
    flex-direction: column;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 10px;
  }
  .messages {
    flex: 1;
    overflow-y: auto;
    margin-bottom: 10px;
  }
  .message {
    margin-bottom: 5px;
  }
  .chat-input {
    display: flex;
    gap: 10px;
  }
  .chat-input input {
    flex: 1;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 5px;
  }
  .chat-input button {
    padding: 10px;
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
  }
  .chat-input button:hover {
    background-color: #0056b3;
  }
  </style>
  