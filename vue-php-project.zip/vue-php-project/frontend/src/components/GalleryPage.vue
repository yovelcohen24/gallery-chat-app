<template>
  <div class="gallery-page">
    <input
      type="text"
      placeholder="What are you looking for?"
      v-model="searchTerm"
      @input="filterPictures"
      class="search-bar"
    />
    <div class="gallery-grid">
      <div
        class="picture-card"
        v-for="picture in filteredPictures"
        :key="picture.id"
        @click="goToPicturePage(picture.id)"
        @mouseover="showTooltip(picture)"
        @mouseleave="hideTooltip"
      >
        <img :src="picture.src" alt="Picture" class="picture-image" />
        <div class="picture-info">
          <h3>{{ picture.name }}</h3>
          <p>By {{ picture.artist }}</p>
          <p class="description">{{ picture.description }}</p>
        </div>
      </div>
    </div>
    <!-- Tooltip -->
    <div
      class="tooltip"
      v-if="tooltip.visible"
      :style="{ top: tooltip.y, left: tooltip.x }"
    >
      <p><strong>Resolution:</strong> 600x400</p>
      <p><strong>Size:</strong> ~20KB</p>
    </div>
  </div>
</template>
  
<script>
export default {
  data() {
    return {
      pictures: [],
      searchTerm: "",
      filteredPictures: [],
      tooltip: {
        visible: false,
        x: "0px",
        y: "0px",
        data: {},
      },
    };
  },
  methods: {
    filterPictures() {
      this.filteredPictures = this.pictures.filter((picture) =>
        `${picture.name} ${picture.artist}`
          .toLowerCase()
          .includes(this.searchTerm.toLowerCase())
      );
    },
    goToPicturePage(id) {
      this.$router.push(`/picture/${id}`);
    },
    showTooltip(picture) {
      this.tooltip.visible = true;
      this.tooltip.data = picture;
      document.addEventListener("mousemove", this.updateTooltipPosition);
    },
    hideTooltip() {
      this.tooltip.visible = false;
      this.tooltip.data = {};
      document.removeEventListener("mousemove", this.updateTooltipPosition);
    },
    updateTooltipPosition(event) {
      this.tooltip.x = `${event.pageX + 10}px`;
      this.tooltip.y = `${event.pageY + 10}px`;
    },
  },
  mounted() {
    fetch("http://localhost:8000/data.php")
      .then((response) => response.json())
      .then((data) => {
        this.pictures = data;
        this.filteredPictures = data;
      })
      .catch((error) => console.error("Error fetching data:", error));
  },
};
</script>

  
  <style>
  .gallery-page {
    padding: 20px;
    font-family: Arial, sans-serif;
  }
  .search-bar {
    width: 100%;
    padding: 10px;
    margin-bottom: 20px;
    font-size: 16px;
    border: 1px solid #ddd;
    border-radius: 5px;
  }
  .gallery-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 20px;
  }
  .picture-card {
    border: 1px solid #ddd;
    border-radius: 8px;
    overflow: hidden;
    text-align: center;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    background: #fff;
    cursor: pointer; 
  }
  .picture-card:hover {
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
  }
  .picture-image {
    width: 100%;
    height: auto;
  }
  .picture-info {
    padding: 10px;
  }
  .description {
    color: #666;
    font-size: 14px;
  }
  .tooltip {
  position: absolute;
  background: rgba(0, 0, 0, 0.8);
  color: white;
  padding: 10px;
  border-radius: 5px;
  font-size: 12px;
  pointer-events: none;
  z-index: 1000;
}
  </style>
  