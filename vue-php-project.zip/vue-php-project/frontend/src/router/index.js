import { createRouter, createWebHistory } from "vue-router";
import GalleryPage from "@/components/GalleryPage.vue";
import PicturePage from "@/components/PicturePage.vue";

const routes = [
  {
    path: "/",
    name: "GalleryPage",
    component: GalleryPage,
  },
  {
    path: "/picture/:id",
    name: "PicturePage",
    component: PicturePage,
  },
];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
});

export default router;
