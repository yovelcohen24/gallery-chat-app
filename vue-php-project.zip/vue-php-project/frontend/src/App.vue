<template>
  <router-view />
</template>

<script>
export default {
  name: "App",
};
</script>

<style>
h1 {
  color: blue;
  font-family: Arial, sans-serif;
}
</style>
